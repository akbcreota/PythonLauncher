param([Parameter(ValueFromRemainingArguments=$true)][string[]]$Args)

function Find-Python {
    $candidates = @()

    # Standard installations
    $standard = Join-Path $env:LOCALAPPDATA "Programs\Python"
    if (Test-Path $standard) {
        $candidates += Get-ChildItem $standard -Directory -EA SilentlyContinue |
                       ForEach-Object { Join-Path $_.FullName "python.exe" }
    }

    # Python Install Manager versions
    $pim = Join-Path $env:LOCALAPPDATA "Python"
    if (Test-Path $pim) {
        $candidates += Get-ChildItem $pim -Directory -EA SilentlyContinue |
                       Where-Object { $_.Name -match "pythoncore" } |
                       ForEach-Object { Join-Path $_.FullName "python.exe" }
    }

    # PATH search
    $candidates += ($env:PATH.Split(";") | ForEach-Object {
        $p = Join-Path $_ "python.exe"
        if (Test-Path $p) { $p }
    })

    return $candidates | Where-Object { Test-Path $_ } | Select-Object -Unique
}

function Get-PythonVersion($exe) {
    try {
        $tmp = [IO.Path]::GetTempFileName() + ".py"
        @"
import sys
print(f"{sys.version_info.major}.{sys.version_info.minor}")
"@ | Out-File -Encoding ascii $tmp

        $v = (& $exe $tmp 2>$null).Trim()
        Remove-Item $tmp -Force
        return $v
    }
    catch { return $null }
}

function Build-VersionMap {
    $map = @{}
    foreach ($exe in Find-Python) {
        $ver = Get-PythonVersion $exe
        if ($ver -and -not $map.ContainsKey($ver)) {
            $map[$ver] = $exe
        }
    }
    return $map
}

$Map = Build-VersionMap

$PreferredDefault = "3.13"   # <-- your chosen default version

# py -0  => list versions
if ($Args.Count -eq 1 -and $Args[0] -eq "-0") {
    Write-Host "Installed Python versions:"
    foreach ($v in $Map.Keys | Sort-Object) {
        Write-Host "  $v  ->  $($Map[$v])"
    }
    exit
}

# py -3.13 / py -3.14 / etc.
if ($Args.Count -gt 0 -and $Args[0] -match "^-([0-9]+\.[0-9]+)$") {
    $ver = $Matches[1]
    if ($Map.ContainsKey($ver)) {
        $rest = @()
        if ($Args.Length -gt 1) {
            $rest = $Args[1..($Args.Length - 1)]
        }
        & $Map[$ver] $rest
        exit
    } else {
        Write-Host "Python $ver not found."
        exit 1
    }
}

# ----- DEFAULT BEHAVIOR -----
# If preferred default exists → use it
if ($Map.ContainsKey($PreferredDefault)) {
    & $Map[$PreferredDefault] $Args
    exit
}

# If not, fallback to highest installed version
if ($Map.Count -gt 0) {
    $fallback = ($Map.Keys | Sort-Object -Descending)[0]
    & $Map[$fallback] $Args
    exit
}

Write-Host "No Python installation found."
exit 1
